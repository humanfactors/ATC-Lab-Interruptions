/**

      @project  : ATC-Lab [performance data]

      @file     : $RCSfile: _header.cpp,v $
      @author   : $Author: Aaron Yeung $
      @version  : $Name:  $ ( $Revision: 1.1.1.2 $ )
      @date     : $Date: 2007/06/21 12:22:41 $
      @state    : $State: Exp $

      $Log: _header.cpp,v $
      Revision 1.1.1.2  2007/06/21 12:22:41  Aaron Yeung
      no message

      Revision 1.1.1.1  2007/06/09 13:12:11  Aaron Yeung
      no message

      Revision 1.1  2006/08/24 04:12:51  seth
      seperating model from visuals


      @email      : atc-support@psy.uq.edu.au
      @copyright  : 2006 ARC Key Center for 
                    Human Factors & Applied Cognitive Psycology

**/

#include "XXX.h"


using namespace YYY;


////////////////////////////////////////////////////////////////////////////////
//
// YYY::XXX
//
//------------------------------------------------------------------------------
// [public] construction
//

/*!
 *
 */
XXX::XXX() {}

/*!
 *
 */
XXX::~XXX() {}


//------------------------------------------------------------------------------
// [public] interface
//


//------------------------------------------------------------------------------
// [private] implementation
//


////////////////////////////////////////////////////////////////////////////////
