#include "interrupt_task.h"
#include <string.h>
#include <qpalette.h>
#include <qpainter.h>

using namespace atc;

////////////////////////////////////////////////////////////////////////////////
//
// Class nBackTask
//
//------------------------------------------------------------------------------
// [public] construction/destruction
//
InterruptTask::InterruptTask(CanvasView* a_canvasView,
                             pact::InterruptionParams a_params)
    :   QDialog((QWidget*) a_canvasView, "InterruptScreen", TRUE, Qt::WStyle_Customize|Qt::WStyle_NoBorder),
        m_params(a_params),
        m_secondsCount(0),
        m_canvasView(a_canvasView)
{
    setBackgroundColor(DEFAULT_BACKGROUND_COLOUR);

    m_countdownDisplay = std::auto_ptr<QLabel>(new QLabel(this));
    m_countdownTimer = std::auto_ptr<QTimer>(new QTimer(this));

    connect(m_countdownTimer.get(), SIGNAL(timeout()), 
			this, SLOT(HandleCountdownTimerTimeout()));

    QFont f(DEFAULT_COUNTDOWN_TIMER_FONT, DEFAULT_COUNTDOWN_TIMER_FONT_SIZE);

	m_countdownDisplay->setFont(f);

    QPalette* palette = new QPalette();

    palette->setColor(QColorGroup::Background, DEFAULT_BACKGROUND_COLOUR);
    palette->setColor(QColorGroup::Foreground, DEFAULT_COUNTDOWN_TIMER_FONT_COLOUR);

    m_countdownDisplay->setPalette(*palette);
}

InterruptTask::~InterruptTask()
{
}

void
InterruptTask::Start()
{
    showFullScreen();
	m_countdownTimer->start(MILLISECONDS_PER_SECOND);
    m_secondsCount = m_params.m_end - m_params.m_start;

    QRect rect = this->geometry();

    m_countdownDisplay->move(rect.width()/2, rect.height()/2);

    DisplayTime();
}

void
InterruptTask::Stop()
{
    hide();
    m_countdownTimer->stop();
}

void
InterruptTask::HandleCountdownTimerTimeout()
{
    m_secondsCount--;

    DisplayTime();
    m_countdownTimer->start(MILLISECONDS_PER_SECOND);
}


void
InterruptTask::DisplayTime()
{
    if (m_params.m_show_timer)
    {
        m_countdownDisplay->setText(atc::to_string(m_secondsCount));
        m_countdownDisplay->adjustSize();
    }
}
