#ifndef __INTERRUPT_TASK_HDR__
#define __INTERRUPT_TASK_HDR__

#include "canvasview.h"
#include "trialtask.h"
#include <qdialog.h>
#include <qlabel.h>
#include <qtimer.h>

namespace atc
{
    const QColor        DEFAULT_BACKGROUND_COLOUR = Qt::black;
    const std::string   DEFAULT_COUNTDOWN_TIMER_FONT = "SansSerif";
    const QColor        DEFAULT_COUNTDOWN_TIMER_FONT_COLOUR = Qt::white;
    const int           DEFAULT_COUNTDOWN_TIMER_FONT_SIZE = 20;

    class InterruptTask : public QDialog 
    {
		Q_OBJECT;

    public:
        InterruptTask(CanvasView* a_canvasView, pact::InterruptionParams a_params);
        ~InterruptTask();

        void Start();
        void Stop();

    private slots:
        void HandleCountdownTimerTimeout();

    private:
        void DisplayTime();

        int                         m_secondsCount;
        std::auto_ptr<QTimer>       m_countdownTimer;
        std::auto_ptr<QLabel>       m_countdownDisplay;
        CanvasView*                 m_canvasView;
        pact::InterruptionParams    m_params;
    };
};

#endif