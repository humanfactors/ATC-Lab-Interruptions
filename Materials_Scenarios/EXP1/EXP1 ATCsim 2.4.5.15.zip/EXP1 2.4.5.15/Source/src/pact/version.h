#ifndef __ATC_VERSION__
#define __ATC_VERSION__

const std::string ATC_VERSION = "2.4.5.15";

#endif
